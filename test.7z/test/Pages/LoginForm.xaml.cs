﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace test.Pages
{
   
    public partial class LoginForm : Page
    {
        public DataTable Select(string selectSQL) //подключение к базе
        {
            DataTable dataTable = new DataTable("dataBase");                
            SqlConnection sqlConnection = new SqlConnection("Data Source=DXD;Initial Catalog=Autification;Integrated Security=True");
            sqlConnection.Open();                                          
            SqlCommand sqlCommand = sqlConnection.CreateCommand();          
            sqlCommand.CommandText = selectSQL;                             
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dataTable);                                 

            sqlConnection.Close();
            return dataTable;
        }


        public LoginForm()
        {
            InitializeComponent();



        }

        private void Registrarion(object sender, RoutedEventArgs e)
        {

            AppData.frame.Content = new SignUpForm();

        }

        private void EnterBut(object sender, RoutedEventArgs e) // проверка логина и пароля, передача данных на MenuItem \ MVVM
        {

            if (usernameform.Text.Length > 0)    
            {
                if (passform.Password.Length > 0)          
                {                     
                    DataTable dt_user  = Select("SELECT * FROM [dbo].[Entry] WHERE [username] = '" + usernameform.Text + "' AND [password] = '" + passform.Password + "'");
                    
                    if (dt_user.Rows.Count>0)
                    {
                        var username = dt_user.Rows[0]["username"].ToString();
                        var password = dt_user.Rows[0]["password"].ToString();

                        if (passform.Password == password)
                        {
                            AppData.User = new User();
                            AppData.User.Name = dt_user.Rows [0]["name"].ToString();
                            //User.Picture = Encoding.UTF8.GetBytes(dt_user.Rows[0]["avatar"].ToString());                           

                            AppData.User.Username = username;
                            AppData.User.Password = password;

                            AppData.User.Avatar = Database.DownloadImageFromDatabase();

                            var menuItem = new MenuItem();
                            menuItem.DataContext = AppData.SharedViewModel;
                            AppData.frame.Content = menuItem;

                        }
                       
                    }
                    else MessageBox.Show("The username or password is incorrect");
                }
                   
            }
            else MessageBox.Show("Enter the username"); 


            
        }
    }
}
